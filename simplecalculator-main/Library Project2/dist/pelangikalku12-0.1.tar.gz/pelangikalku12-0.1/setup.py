from setuptools import setup

setup(
    name='pelangikalku12',
    version='0.1',
    packages=['simplecalculator'],
    install_requires=[],
    entry_points={},
    url='https://github.com/codewithun/simplecalculator',
    license='MIT',
    author='Untara Saputra',
    author_email='untara337@example.com',
    description='Simplecalculator yang membuat pusing.',
)
